package com.betacom.bec.services.implementations;


import org.springframework.stereotype.Service;

import com.betacom.bec.services.interfaces.CarrelloProdottoServices;



@Service
public class CarrelloProdottoImpl implements CarrelloProdottoServices{


    
}