package com.betacom.bec.services.interfaces;

public interface MessaggioServices {
	
	String getMessaggio(String code);

}
