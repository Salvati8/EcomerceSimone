package com.betacom.bec.services.interfaces;

public interface CarrelloProdottoServices {

}